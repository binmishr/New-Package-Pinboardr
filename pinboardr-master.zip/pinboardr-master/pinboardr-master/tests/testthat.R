library(testthat)
library(pinboardr)

test_check("pinboardr")
