## Test environments
* local OS X install, R 3.6.3, R version 4.0.2 and against unstable 4.1 (2020-08-02 r78957)
* ubuntu 14.04 (on travis-ci), R 3.6.3
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note

* This is a new release.
* Changed URL to Code of Conduct to fully specified URL.
