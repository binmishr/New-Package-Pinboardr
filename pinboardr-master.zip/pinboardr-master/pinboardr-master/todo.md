# TODO
- describe where you find your username and token
- [ ] move helperfunctions and their tests
- [] pb_posts_all
- [] go through all endpoints and check if required arguments are clear
test concat args, 
- [] describe what resulting dataframe looks like, even modify names?
- [x] check spelling tags/tag

    user
        user/secret
        user/api_token

    notes
        notes/list
        notes/ID


###  Future improvements
- [] rate limit, by exponential backoff
- [] allow for global settings for public bookmarks, unread
